run lev function before runnig logicsim,dfs,pfs,rtg

./simulator
read circuit.ckt
lev "generate the level file name"
logicsim "read the txt file name" "generate the output name"
dfs "test pattern file" "output name"
pfs "fault list file" "test pattern file" "output name"
rtg "number of test vectors" "frequency" "generated test_vector file" "generated fault coverage"

The order of detected fault during dfs and pfs may be different from golden file, but the contents are the same.

All_faultlist are generated during rtg running process, we copy the result in an txt file as the input file of pfs.
#!/bin/bash
#Run this in terminal

g++ -std=c++0x phase2.cpp -o simulator -pthread
exit 0
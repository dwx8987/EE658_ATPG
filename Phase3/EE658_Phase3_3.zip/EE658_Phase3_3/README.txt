The circuit has been levelized.

./simulator
read circuit.ckt
lev "generate the level file name"
logicsim "read the txt file name" "generate the output name"
rfl "output name"
dfs "test pattern file" "output name"
pfs "fault list file" "test pattern file" "output name"
rtg "number of test vectors" "frequency" "generated test_vector file" "generated fault coverage"

dalg "node" "fault value"
podem "node" "fault value"
atpg_det "circuit name" "algorithm"
Atpg "circuit name"

All_faultlist are generated during rtg running process, we copy the result in an txt file as the input file of pfs.